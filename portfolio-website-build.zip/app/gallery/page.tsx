'use client';

import Sidebar from '@/components/Sidebar';
import TopToggle from '@/components/TopToggle';
import BirdCursor from '@/components/BirdCursor';
import { motion } from 'framer-motion';
import styles from './gallery.module.css';

const galleryItems = [
  {
    id: 1,
    title: 'Web Development Journey',
    designer: 'Nishchay Sinha',
    image: 'linear-gradient(135deg, #4a7c59 0%, #2d5a3d 100%)',
  },
  {
    id: 2,
    title: 'System Architecture & Design',
    designer: 'Nishchay Sinha',
    image: 'linear-gradient(135deg, #5a4a7c 0%, #3d2d5a 100%)',
  },
  {
    id: 3,
    title: 'Full Stack Innovation',
    designer: 'Nishchay Sinha',
    image: 'linear-gradient(135deg, #7c5a4a 0%, #5a3d2d 100%)',
  },
  {
    id: 4,
    title: 'Technical Excellence',
    designer: 'Nishchay Sinha',
    image: 'linear-gradient(135deg, #4a7c7c 0%, #2d5a5a 100%)',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: 'easeOut' },
  },
};

export default function Gallery() {
  return (
    <div className={styles.page}>
      <Sidebar />
      <TopToggle />
      <BirdCursor />

      <motion.div className={styles.container} variants={containerVariants} initial="hidden" animate="visible">
        {/* Header */}
        <motion.div variants={itemVariants} className={styles.header}>
          <h1 className={styles.title}>Project Gallery</h1>
          <div className={styles.handle}>@nishchay_dev</div>
        </motion.div>
        <motion.hr variants={itemVariants} style={{ marginBottom: '60px' }} />

        {/* Gallery Grid */}
        <div className={styles.grid}>
          {galleryItems.map((item, idx) => (
            <motion.div key={item.id} variants={itemVariants} className={styles.galleryItem} whileHover={{ y: -4 }}>
              <div className={styles.image} style={{ background: item.image }} />
              <div className={styles.caption}>
                <h3 className={styles.itemTitle}>{item.title}</h3>
                <div className={styles.itemMeta}>
                  <span className={styles.label}>Developer</span>
                  <span className={styles.author}>{item.designer}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
