'use client';

import { useEffect, useRef } from 'react';

interface Point {
  x: number;
  y: number;
}

const BirdCursor = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mousePos = useRef<Point>({ x: 0, y: 0 });
  const trail = useRef<Point[]>([]);
  const trailLength = 12;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Track mouse position
    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current = { x: e.clientX, y: e.clientY };
    };
    window.addEventListener('mousemove', handleMouseMove);

    // Animation loop
    let animationFrameId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Add new point to trail
      trail.current.unshift({ ...mousePos.current });
      if (trail.current.length > trailLength) {
        trail.current.pop();
      }

      // Draw the bird/trail
      if (trail.current.length > 0) {
        ctx.save();
        ctx.filter = 'blur(1px)';

        // Draw trail with gradient opacity
        for (let i = trail.current.length - 1; i >= 0; i--) {
          const point = trail.current[i];
          const opacity = (i / trail.current.length) * 0.7;

          ctx.globalAlpha = opacity;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';

          // Draw small circles for trail effect
          const size = 2 + (i / trail.current.length) * 4;
          ctx.beginPath();
          ctx.arc(point.x, point.y, size, 0, Math.PI * 2);
          ctx.fill();
        }

        // Draw the bird head at current position
        const head = trail.current[0];
        ctx.globalAlpha = 1;
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';

        // Bird body - elongated shape
        ctx.beginPath();
        ctx.ellipse(head.x, head.y, 8, 5, 0.2, 0, Math.PI * 2);
        ctx.fill();

        // Bird beak
        ctx.beginPath();
        ctx.moveTo(head.x + 7, head.y);
        ctx.lineTo(head.x + 12, head.y - 2);
        ctx.lineTo(head.x + 11, head.y + 2);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        pointerEvents: 'none',
        zIndex: 150,
      }}
    />
  );
};

export default BirdCursor;
