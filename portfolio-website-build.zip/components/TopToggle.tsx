'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import styles from './toggle.module.css';

const TopToggle = () => {
  const [isDark, setIsDark] = useState(true);

  return (
    <motion.div
      className={styles.toggle}
      onClick={() => setIsDark(!isDark)}
      whileHover={{ cursor: 'pointer' }}
    >
      <motion.div
        className={styles.knob}
        animate={{ x: isDark ? 2 : 32 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
      />
    </motion.div>
  );
};

export default TopToggle;
